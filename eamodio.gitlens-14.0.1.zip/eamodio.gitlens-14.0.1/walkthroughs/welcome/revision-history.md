<figure align="center">
  <img src="../../images/docs/revision-navigation.gif" alt="Revision Navigation" />
  <figcaption>Revision Navigation</figcaption>
</figure>
