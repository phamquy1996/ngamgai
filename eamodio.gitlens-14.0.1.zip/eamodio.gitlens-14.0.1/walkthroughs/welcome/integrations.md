<figure align="center">
  <img src="../../images/docs/hosting-integrations.png" alt="Hosting service integrations"/>
</figure>
